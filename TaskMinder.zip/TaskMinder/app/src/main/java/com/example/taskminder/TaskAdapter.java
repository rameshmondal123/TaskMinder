package com.example.taskminder;

import android.content.Context;
import android.content.Intent;
import android.provider.CalendarContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.textview.MaterialTextView;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    Context mcontext;
    List<TaskModel> tasklist = new ArrayList<>();

    public TaskAdapter(Context mcontext, List<TaskModel> tasklist) {
        this.mcontext = mcontext;
        this.tasklist = tasklist;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(mcontext).inflate(R.layout.single_task, parent,false);


        return new  TaskViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        TaskModel singletask = tasklist.get(position);
        holder.title.setText(singletask.getTitle());
        holder.description.setText(singletask.getDescription());
        if(singletask.getStatus().equals("PENDING")){
            holder.taskcard.setCardBackgroundColor(mcontext.getResources().getColor(R.color.blackish));
        }
        if(singletask.getStatus().equals("IN PROGRESS")){
            holder.taskcard.setCardBackgroundColor(mcontext.getResources().getColor(R.color.yellow));
        }
        if(singletask.getStatus().equals("COMPLETED")){
            holder.taskcard.setCardBackgroundColor(mcontext.getResources().getColor(R.color.green));
        }
        holder.taskcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent( mcontext, TaskManage.class);
                intent.putExtra("taskId", singletask.getId());
                mcontext.startActivity( intent);
            }
        });

    }



    @Override
    public int getItemCount() {
        return tasklist.size();
    }
    public class TaskViewHolder extends RecyclerView.ViewHolder {
        MaterialTextView title, description;
        MaterialCardView taskcard;
        CircleImageView task_image;
        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.singletasktitle);
            taskcard = itemView.findViewById(R.id.taskcard);
            task_image = itemView.findViewById(R.id.profile_image);
            description = itemView.findViewById(R.id.singletaskdescription);
        }


    }


}
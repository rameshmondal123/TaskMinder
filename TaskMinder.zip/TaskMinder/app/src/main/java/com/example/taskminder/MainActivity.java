package com.example.taskminder;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textview.MaterialTextView;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private NavigationView navview;
    private Toolbar toolbar;
    private UserService userService;
    private  User user;
    private TextView navHeaderTitle;
    private MaterialTextView email;
    private  CircleImageView profile_pic;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        if (!Checklogin.isloggedin(this)){
            startActivity(new Intent(this, LoginPage.class));
            finish();
        }
        userService = new UserService(this);
        userService.open();
        int id=Checklogin.getuserid(this);
        if (id==0){
            startActivity(new Intent(this, LoginPage.class));
            finish();
        }
        user = userService.getUserById(id);


        drawerLayout = findViewById(R.id.main);
        navview = findViewById(R.id.navview);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout,toolbar, R.string.opendrawer, R.string.closedrawer);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        boolean reload= getIntent().getBooleanExtra("reload",false);
        if(reload){
            loadFragment(new TaskList());
        }
        else{
            loadFragment(new Dashboard());
        }

        View v = navview.getHeaderView(0);
        navHeaderTitle = v.findViewById(R.id.name);
        navHeaderTitle.setText(user.getFullName());
        email = v.findViewById(R.id.emailid);
        email.setText(user.getEmail());
        profile_pic = v.findViewById(R.id.profilepic);
        String imagePath =user.getProfilePic();
        if (imagePath.equals("default_profile_pic")){
            profile_pic.setImageDrawable(getDrawable(R.drawable.profilepic));
        }
        else{
            profile_pic.setImageURI(Uri.fromFile(new File(imagePath)));
        }




        navview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id == R.id.dashboard){
                    loadFragment(new Dashboard());
                    drawerLayout.close();
                }
                else if (id==R.id.tasklist){
                    loadFragment(new TaskList());
                    drawerLayout.close();
                }
                else if (id == R.id.calendar){
                    loadFragment(new Calendar());
                    drawerLayout.close();
                }
                else if (id == R.id.settings){
                    loadFragment( new ProfileFragment());
                    drawerLayout.close();
                }
                return true;
            }
        });

    }
    public  void loadFragment(Fragment fragment){
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.main_content, fragment).commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        userService.close();
    }
}
package com.example.taskminder;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.util.Range;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class UserService {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public UserService(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    // Method to create a user
    public void createUser(String fullName, String email, String password, String profilePic) {
        String encryptedPassword = encryptPassword(password);
        ContentValues values = new ContentValues();
        values.put("full_name", fullName);
        values.put("email", email);
        values.put("password", encryptedPassword);
        values.put("profilepic", profilePic);

        try {
            db.insertOrThrow("user", null, values);
        } catch (SQLiteException e) {
            System.out.println(e.getMessage());
        }
    }

    // Method to login a user
    @SuppressLint("Range")
    public User loginUser(String email, String password) {
        String encryptedPassword = encryptPassword(password);
        String[] columns = {"id", "full_name", "email", "password", "profilepic"};
        String selection = "email = ? AND password = ?";
        String[] selectionArgs = {email, encryptedPassword};

        Cursor cursor = db.query("user", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            User user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndex("id")));
            user.setFullName(cursor.getString(cursor.getColumnIndex("full_name")));
            user.setEmail(cursor.getString(cursor.getColumnIndex("email")));
            user.setPassword(cursor.getString(cursor.getColumnIndex("password")));
            user.setProfilePic(cursor.getString(cursor.getColumnIndex("profilepic")));
            cursor.close();
            return user;
        }

        if (cursor != null) {
            cursor.close();
        }

        return null;
    }

    // Method to update a user
    public void updateUser(int id, String fullName, String email, String password, String profilePic) {
        String encryptedPassword = encryptPassword(password);
        ContentValues values = new ContentValues();
        values.put("full_name", fullName);
        values.put("email", email);
        values.put("password", encryptedPassword);
        values.put("profilepic", profilePic);

        String whereClause = "id = ?";
        String[] whereArgs = {String.valueOf(id)};

        try {
            db.update("user", values, whereClause, whereArgs);
        } catch (SQLiteException e) {
            System.out.println(e.getMessage());
        }
    }

    // Helper method to encrypt a password using MD5
    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes());
            byte[] bytes = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
    @SuppressLint("Range")
    public User getUserById(int userId) {
        String[] columns = {"id", "full_name", "email", "password", "profilepic"};
        String selection = "id = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query("user", columns, selection, selectionArgs, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            User user = new User();
            user.setId(cursor.getInt(cursor.getColumnIndex("id")));
            user.setFullName(cursor.getString(cursor.getColumnIndex("full_name")));
            user.setEmail(cursor.getString(cursor.getColumnIndex("email")));
            user.setPassword(cursor.getString(cursor.getColumnIndex("password")));
            user.setProfilePic(cursor.getString(cursor.getColumnIndex("profilepic")));
            cursor.close();
            return user;
        }

        if (cursor != null) {
            cursor.close();
        }

        return null;
    }

}

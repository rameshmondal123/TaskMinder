package com.example.taskminder;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TaskService {
    private SQLiteDatabase db;
    private DatabaseHelper dbHelper;

    public TaskService(Context context) {
        dbHelper = new DatabaseHelper(context);
    }

    public void open() {
        db = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public void addTask(TaskModel task) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITLE, task.getTitle());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, task.getDescription());
        values.put(DatabaseHelper.COLUMN_DUE_DATE, task.getDueDate());
        values.put(DatabaseHelper.COLUMN_PRIORITY, task.getPriority());
        values.put(DatabaseHelper.COLUMN_STATUS, task.getStatus());
        values.put(DatabaseHelper.COLUMN_CREATION_DATE, task.getCreationDate());
        values.put(DatabaseHelper.COLUMN_UPDATE_DATE, task.getUpdateDate());
        values.put(DatabaseHelper.COLUMN_CATEGORY, task.getCategory());
        values.put(DatabaseHelper.COLUMN_REMINDER, task.isReminder() ? 1 : 0);

        db.insert(DatabaseHelper.TABLE_TASKS, null, values);
    }

    public List<TaskModel> getAllTasks() {
        List<TaskModel> tasks = new ArrayList<>();

        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, null, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                TaskModel task = cursorToTask(cursor);
                tasks.add(task);
                cursor.moveToNext();
            }
            cursor.close();
        }

        return tasks;
    }

    public Map<String, Integer> getTaskReport() {
        List<TaskModel> tasks = new ArrayList<>();
        Map<String, Integer> statusReport = new HashMap<>();
        Set<String> uniqueCategories = new HashSet<>();

        // Initialize the status counts
        statusReport.put("PENDING", 0);
        statusReport.put("IN PROGRESS", 0);
        statusReport.put("COMPLETED", 0);
        statusReport.put("ON HOLD", 0);

        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, null, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                TaskModel task = cursorToTask(cursor);
                tasks.add(task);
                String status = task.getStatus();
                if (statusReport.containsKey(status)) {
                    statusReport.put(status, statusReport.get(status) + 1);
                }
                String category = task.getCategory();
                uniqueCategories.add(category);


                cursor.moveToNext();
            }
            cursor.close();
        }
        statusReport.put("category", uniqueCategories.size());
        return  statusReport;

    }


    public TaskModel getTask(int id) {
        Cursor cursor = db.query(DatabaseHelper.TABLE_TASKS, null, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            TaskModel task = cursorToTask(cursor);
            cursor.close();
            return task;
        } else {
            return null;
        }
    }

    public int updateTask(TaskModel task) {
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITLE, task.getTitle());
        values.put(DatabaseHelper.COLUMN_DESCRIPTION, task.getDescription());
        values.put(DatabaseHelper.COLUMN_DUE_DATE, task.getDueDate());
        values.put(DatabaseHelper.COLUMN_PRIORITY, task.getPriority());
        values.put(DatabaseHelper.COLUMN_STATUS, task.getStatus());
        values.put(DatabaseHelper.COLUMN_CREATION_DATE, task.getCreationDate());
        values.put(DatabaseHelper.COLUMN_UPDATE_DATE, task.getUpdateDate());
        values.put(DatabaseHelper.COLUMN_CATEGORY, task.getCategory());
        values.put(DatabaseHelper.COLUMN_REMINDER, task.isReminder() ? 1 : 0);

        return db.update(DatabaseHelper.TABLE_TASKS, values, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(task.getId())});
    }

    public void deleteTask(int id) {
        db.delete(DatabaseHelper.TABLE_TASKS, DatabaseHelper.COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    private TaskModel cursorToTask(Cursor cursor) {
        TaskModel task = new TaskModel();
        task.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_ID)));
        task.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_TITLE)));
        task.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DESCRIPTION)));
        task.setDueDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DUE_DATE)));
        task.setPriority(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRIORITY)));
        task.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_STATUS)));
        task.setCreationDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CREATION_DATE)));
        task.setUpdateDate(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_UPDATE_DATE)));
        task.setCategory(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_CATEGORY)));
        task.setReminder(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_REMINDER)) == 1);

        return task;
    }
}

package com.example.taskminder;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;
import  java.util.Calendar;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Arrays;
import java.util.List;

public class TaskManage extends AppCompatActivity {

    private TextInputEditText editTextTitle, editTextDescription, editTextCategory;
    private TextInputEditText editTextDueDate;
    private Switch switchReminder;
    private Spinner editTextStatus,editTextPriority;
    private Button buttonSave;
    private TextInputLayout duedate;

    private TaskService taskService;
    private int taskId = -1;
    private  String[] status = { "PENDING", "IN PROGRESS",
            "COMPLETED", "ON HOLD"};
    private  String current_status =status[0];
    List<String> statusList = Arrays.asList(status);

    private  String[] priority = { "LOW", "MEDIUM",
            "HIGH", "HiGHEST"};
    private  String current_priority =priority[0];
    List<String> priorityList = Arrays.asList(priority);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_manage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.taskmanageview), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDescription = findViewById(R.id.editTextDescription);
        editTextDueDate = findViewById(R.id.editTextDueDate);
        editTextPriority = findViewById(R.id.editTextPriority);
        editTextStatus = findViewById(R.id.editTextStatus);
        editTextCategory = findViewById(R.id.editTextCategory);
        switchReminder = findViewById(R.id.switchReminder);
        buttonSave = findViewById(R.id.buttonSave);
        duedate= findViewById(R.id.dudate);
        duedate.setStartIconOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectDate();
            }
        });
//        editTextDueDate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                selectDate();
//            }
//        });

        editTextStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                current_status= status[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                current_status= status[0];
            }
        });
        ArrayAdapter ad
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                status);
        ad.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);
        editTextStatus.setAdapter(ad);


        editTextPriority.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                current_priority = priority[position];
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                current_priority = priority[0];
            }
        });
        ArrayAdapter ad2
                = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                priority);
        ad2.setDropDownViewResource(
                android.R.layout
                        .simple_spinner_dropdown_item);
        editTextPriority.setAdapter(ad2);

        taskService = new TaskService(this);
        taskService.open();

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("taskId")) {
            taskId = intent.getIntExtra("taskId", -1);
            if (taskId != -1) {
                loadTask(taskId);
            }
        }

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });
    }

    private void loadTask(int id) {
        TaskModel task = taskService.getTask(id);
        if (task != null) {
            editTextTitle.setText(task.getTitle());
            editTextDescription.setText(task.getDescription());
            editTextDueDate.setText(task.getDueDate());
            editTextPriority.setSelection(priorityList.indexOf(task.getPriority()));
            editTextStatus.setSelection(statusList.indexOf(task.getStatus()));
            editTextCategory.setText(task.getCategory());
            switchReminder.setChecked(task.isReminder());
        }
    }

    private void saveTask() {
        String title = editTextTitle.getText().toString();
        String description = editTextDescription.getText().toString();
        String dueDate = editTextDueDate.getText().toString();
        String priority = current_priority;
        String status = current_status;
        String category = editTextCategory.getText().toString();
        boolean reminder = switchReminder.isChecked();

        if (title.isEmpty() || description.isEmpty() || dueDate.isEmpty() || priority.isEmpty() || status.isEmpty() || category.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        TaskModel task = new TaskModel(taskId, title, description, dueDate, priority, status, null, null, category, reminder);

        if (taskId == -1) {
            taskService.addTask(task);
            Toast.makeText(this, "Task added", Toast.LENGTH_SHORT).show();
        } else {
            taskService.updateTask(task);
            Toast.makeText(this, "Task updated", Toast.LENGTH_SHORT).show();
        }
        Intent done = new Intent(this, MainActivity.class);
        done.putExtra("reload",true);
        startActivity(done);
        finish();
    }

    @Override
    protected void onDestroy() {
        taskService.close();
        super.onDestroy();
    }

    public void selectDate(){
        final Calendar c = Calendar.getInstance();

        // on below line we are getting
        // our day, month and year.
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        // on below line we are creating a variable for date picker dialog.
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                // on below line we are passing context.
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {
                        // on below line we are setting date to our text view.
                        editTextDueDate.setText(  year+"-"+(monthOfYear + 1)+"-"+dayOfMonth);

                    }
                },
                // on below line we are passing year,
                // month and day for selected date in our date picker.
                year, month, day);
        // at last we are calling show to
        // display our date picker dialog.
        datePickerDialog.show();
    }

}
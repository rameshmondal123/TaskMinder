package com.example.taskminder;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textview.MaterialTextView;

import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Dashboard#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Dashboard extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private MaterialTextView greeting;
    private  MaterialTextView pending, ongoing, completed, category,pendingmsg;
    private MaterialCardView pendingcard, ongoingcard, completedcard, categorycard;
    public Dashboard() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Dashboard.
     */
    // TODO: Rename and change types and number of parameters
    public static Dashboard newInstance(String param1, String param2) {
        Dashboard fragment = new Dashboard();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_dashboard, container, false);
        UserService userService = new UserService(getContext());
        userService.open();
        TaskService taskService = new TaskService(getContext());
        taskService.open();
        ongoing=v.findViewById(R.id.inprogresstaskcount);
        pending=v.findViewById(R.id.pending_taskcount);
        completed=v.findViewById(R.id.completedtaskcount);
        category=v.findViewById(R.id.categorycount);
        pendingmsg=v.findViewById(R.id.pendingmsg);
        pendingcard=v.findViewById(R.id.pendingcard);
        ongoingcard=v.findViewById(R.id.ongoingcard);
        completedcard=v.findViewById(R.id.completedcard);
        categorycard=v.findViewById(R.id.categorycard);
        pendingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gototask_page();
            }
        });

        ongoingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gototask_page();
            }
        });


        completedcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gototask_page();
            }
        });
        categorycard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gototask_page();
            }
        });



        Map<String, Integer> data= taskService.getTaskReport();
        if(data.get("PENDING") ==0){
            pendingmsg.setText("Hurray ! No Pending task are there");
        }
        else{
            pendingmsg.setText(String.valueOf(data.get("PENDING")) +" task is in pending !");
        }
        ongoing.setText(String.valueOf(data.get("IN PROGRESS")));
        pending.setText(String.valueOf(data.get("PENDING")));
        completed.setText(String.valueOf(data.get("COMPLETED")));
        category.setText(String.valueOf(data.get("category")));
        int id=Checklogin.getuserid(getContext());
        if (id==0){
            startActivity(new Intent(getContext(), LoginPage.class));
            getActivity().finish();
        }
        User user = userService.getUserById(id);

        FloatingActionButton addbtn = v.findViewById(R.id.addtaskbtn);
        greeting = v.findViewById(R.id.greetingname);
        greeting.setText("Hii "+user.getFullName() +" !");
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), TaskManage.class));
            }
        });
        return v;
    }
    public void gototask_page(){
        Intent done = new Intent(getContext(), MainActivity.class);
        done.putExtra("reload",true);
        startActivity(done);
    }
}
package com.example.taskminder;

import android.content.Context;
import android.content.SharedPreferences;

public class Checklogin {

    public  static boolean isloggedin(Context ctx){
        SharedPreferences pref = ctx.getSharedPreferences("usercred", ctx.MODE_PRIVATE);
        if (pref.contains("userId")){
            return true;
        }
        else{
            return false ;
        }

    }
    public  static int getuserid(Context ctx){
        SharedPreferences pref = ctx.getSharedPreferences("usercred", ctx.MODE_PRIVATE);
        if (pref.contains("userId")){
            return  pref.getInt("userId", 0);
        }
        else{
            return 0 ;
        }

    }
}

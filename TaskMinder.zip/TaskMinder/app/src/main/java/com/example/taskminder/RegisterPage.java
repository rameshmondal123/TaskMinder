package com.example.taskminder;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textview.MaterialTextView;

public class RegisterPage extends AppCompatActivity {
    private MaterialTextView gotologingpage;
    private TextInputEditText nameEditText;
    private TextInputEditText emailEditText;
    private TextInputEditText passwordEditText;
    private Button registerButton;
    private UserService userService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register_page);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        gotologingpage = findViewById(R.id.gotologinpage);
        gotologingpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterPage.this, LoginPage.class));
            }
        });

        userService = new UserService(this);
        userService.open();

        // Find views
        nameEditText = findViewById(R.id.reg_name);
        emailEditText = findViewById(R.id.reg_email);
        passwordEditText = findViewById(R.id.regpassword);
        registerButton = findViewById(R.id.login_button);

        // Set up register button click listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }
    private void registerUser() {
        // Retrieve user input
        String fullName = nameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate input
        if (fullName.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create user
        userService.createUser(fullName, email, password, "default_profile_pic"); // Replace with actual profile pic if needed

        // Notify user and clear fields
        Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show();
        nameEditText.setText("");
        emailEditText.setText("");
        passwordEditText.setText("");
        startActivity(new Intent(RegisterPage.this, LoginPage.class));
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        userService.close();
    }

}